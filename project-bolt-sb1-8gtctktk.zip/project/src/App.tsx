import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './contexts/ToastContext';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import OnBoarding from './pages/auth/OnBoarding';
import Dashboard from './pages/dashboard/Dashboard';
import ResourceFeed from './pages/resources/ResourceFeed';
import ResourceDetail from './pages/resources/ResourceDetail';
import CreateListing from './pages/resources/CreateListing';
import Inbox from './pages/messaging/Inbox';
import ChatThread from './pages/messaging/ChatThread';
import Transactions from './pages/transactions/Transactions';
import TransactionDetail from './pages/transactions/TransactionDetail';
import Profile from './pages/profile/Profile';
import NotFound from './pages/NotFound';

// Protected Route Component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { currentUser, loading } = useAuth();
  
  if (loading) {
    return <div className="h-screen flex items-center justify-center">
      <div className="animate-pulse-slow">Loading...</div>
    </div>;
  }
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <ToastProvider>
          <AuthProvider>
            <Routes>
              {/* Auth Routes */}
              <Route element={<AuthLayout />}>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/onboarding" element={
                  <ProtectedRoute>
                    <OnBoarding />
                  </ProtectedRoute>
                } />
              </Route>
              
              {/* Main App Routes */}
              <Route element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }>
                <Route path="/" element={<Dashboard />} />
                <Route path="/resources" element={<ResourceFeed />} />
                <Route path="/resources/:id" element={<ResourceDetail />} />
                <Route path="/create-listing" element={<CreateListing />} />
                <Route path="/inbox" element={<Inbox />} />
                <Route path="/chat/:id" element={<ChatThread />} />
                <Route path="/transactions" element={<Transactions />} />
                <Route path="/transactions/:id" element={<TransactionDetail />} />
                <Route path="/profile" element={<Profile />} />
              </Route>
              
              {/* 404 Route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </ToastProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}

export default App;