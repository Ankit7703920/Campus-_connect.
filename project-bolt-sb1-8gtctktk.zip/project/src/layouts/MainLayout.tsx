import React, { useState } from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { Home, BookOpen, MessageSquare, BarChart3, User, Menu, X, Sun, Moon, Bell } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';

const MainLayout = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { currentUser, logout } = useAuth();
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { path: '/', icon: <Home size={20} />, label: 'Home' },
    { path: '/resources', icon: <BookOpen size={20} />, label: 'Resources' },
    { path: '/inbox', icon: <MessageSquare size={20} />, label: 'Messages' },
    { path: '/transactions', icon: <BarChart3 size={20} />, label: 'Transactions' },
    { path: '/profile', icon: <User size={20} />, label: 'Profile' },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary-500 mr-2">Campus Connect</h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            <button 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors relative"
              aria-label="Notifications"
            >
              <Bell size={20} />
              <span className="absolute top-1 right-1 bg-primary-500 rounded-full w-2 h-2"></span>
            </button>
            
            <button 
              className="md:hidden p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              onClick={toggleMobileMenu}
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            
            {currentUser && (
              <div className="hidden md:flex items-center">
                <div className="h-8 w-8 rounded-full bg-primary-500 text-white flex items-center justify-center mr-2">
                  {currentUser.displayName?.charAt(0) || 'U'}
                </div>
                <span className="text-sm font-medium dark:text-white">{currentUser.displayName || 'User'}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-20 bg-black bg-opacity-50" onClick={toggleMobileMenu}>
          <div 
            className="absolute right-0 top-0 h-full w-64 bg-white dark:bg-gray-800 shadow-lg p-4 transform transition-transform duration-300 animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold text-primary-500">Menu</h2>
              <button onClick={toggleMobileMenu}>
                <X size={20} className="text-gray-500" />
              </button>
            </div>
            
            <nav className="space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={toggleMobileMenu}
                  className={({ isActive }) => 
                    `flex items-center p-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300' 
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200'
                    }`
                  }
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </NavLink>
              ))}
            </nav>

            <div className="absolute bottom-8 left-0 right-0 px-4">
              <button 
                onClick={logout}
                className="w-full py-2 text-center text-red-500 hover:text-red-600 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-screen fixed">
        <div className="w-16 lg:w-64 h-full bg-white dark:bg-gray-800 shadow-sm flex flex-col pt-20">
          <nav className="flex-1 px-2 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={`flex items-center p-3 rounded-lg transition-colors ${
                  isActive(item.path) 
                    ? 'bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-300' 
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200'
                }`}
              >
                {item.icon}
                <span className="ml-3 hidden lg:block">{item.label}</span>
              </NavLink>
            ))}
          </nav>
          
          <div className="p-3 mb-6">
            <button 
              onClick={logout}
              className="w-full flex items-center justify-center lg:justify-start p-3 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v14a1 1 0 01-1 1H4a1 1 0 01-1-1V3zm6 9a1 1 0 100 2h4a1 1 0 100-2H9z" clipRule="evenodd" />
              </svg>
              <span className="ml-3 hidden lg:block">Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="md:ml-16 lg:ml-64 pt-4 pb-20 transition-all duration-200">
        <div className="container mx-auto px-4">
          <Outlet />
        </div>
      </main>

      {/* Mobile Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg z-10">
        <nav className="flex justify-around">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center py-3 px-2 ${
                isActive(item.path) 
                  ? 'text-primary-500' 
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default MainLayout;