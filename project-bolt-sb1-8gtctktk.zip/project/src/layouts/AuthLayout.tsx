import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { GraduationCap as Graduation, Sun, Moon } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const AuthLayout = () => {
  const { currentUser, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  
  // If user is already logged in and not on onboarding page, redirect to dashboard
  if (currentUser && !loading && window.location.pathname !== '/onboarding') {
    return <Navigate to="/" replace />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col transition-colors duration-200">
      <header className="w-full p-4 flex justify-between items-center">
        <div className="flex items-center text-primary-500 font-bold text-xl">
          <Graduation className="mr-2" size={24} />
          <span>Campus Connect</span>
        </div>
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md">
          {loading ? (
            <div className="text-center">
              <div className="animate-pulse-slow">Loading...</div>
            </div>
          ) : (
            <Outlet />
          )}
        </div>
      </main>
      
      <footer className="py-4 text-center text-gray-500 dark:text-gray-400 text-sm">
        <p>© 2025 Campus Connect. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AuthLayout;