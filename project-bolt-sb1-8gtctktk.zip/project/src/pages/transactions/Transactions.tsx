import React, { useState } from 'react';
import { Filter, ShoppingCart, Inbox, CheckCircle, Clock, Calendar } from 'lucide-react';
import TransactionCard from '../../components/transactions/TransactionCard';

// Mock data
const transactions = [
  {
    id: '1',
    title: 'Research Methods Textbook',
    price: 35,
    status: 'completed',
    date: new Date(Date.now() - 172800000).toISOString(),
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Statistical Analysis Tutoring',
    price: 25,
    status: 'pending',
    date: new Date().toISOString(),
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '3',
    title: 'Desk Lamp with USB Charging',
    price: 25,
    status: 'completed',
    date: new Date(Date.now() - 604800000).toISOString(),
    user: {
      id: 'user5',
      name: 'David Park',
      avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '4',
    title: 'Physics Lab Equipment Rental',
    price: 15,
    status: 'cancelled',
    date: new Date(Date.now() - 1209600000).toISOString(),
    user: {
      id: 'user2',
      name: 'Samantha Lee',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '5',
    title: 'Computer Science Tutoring (3 sessions)',
    price: 90,
    status: 'pending',
    date: new Date(Date.now() - 86400000).toISOString(),
    user: {
      id: 'user6',
      name: 'Olivia Martinez',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const Transactions = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  
  // Filter transactions based on selected filter
  const filteredTransactions = transactions.filter(transaction => {
    if (selectedFilter === 'all') return true;
    return transaction.status === selectedFilter;
  });
  
  // Sort transactions
  const sortedTransactions = [...filteredTransactions].sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    
    if (sortBy === 'newest') return dateB - dateA;
    if (sortBy === 'oldest') return dateA - dateB;
    if (sortBy === 'highest') return b.price - a.price;
    if (sortBy === 'lowest') return a.price - b.price;
    
    return 0;
  });
  
  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Transactions
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Manage your buying and selling history
        </p>
      </div>
      
      {/* Filters and sorting */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-3 py-1.5 rounded-full flex items-center text-sm ${
              selectedFilter === 'all'
                ? 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Filter className="h-4 w-4 mr-1.5" />
            All
          </button>
          <button
            onClick={() => setSelectedFilter('pending')}
            className={`px-3 py-1.5 rounded-full flex items-center text-sm ${
              selectedFilter === 'pending'
                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Clock className="h-4 w-4 mr-1.5" />
            Pending
          </button>
          <button
            onClick={() => setSelectedFilter('completed')}
            className={`px-3 py-1.5 rounded-full flex items-center text-sm ${
              selectedFilter === 'completed'
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <CheckCircle className="h-4 w-4 mr-1.5" />
            Completed
          </button>
          <button
            onClick={() => setSelectedFilter('cancelled')}
            className={`px-3 py-1.5 rounded-full flex items-center text-sm ${
              selectedFilter === 'cancelled'
                ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <X className="h-4 w-4 mr-1.5" />
            Cancelled
          </button>
        </div>
        
        <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            {sortedTransactions.length} transaction{sortedTransactions.length !== 1 ? 's' : ''}
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500 dark:text-gray-400">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="highest">Highest Price</option>
              <option value="lowest">Lowest Price</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Transaction list */}
      <div className="space-y-4">
        {sortedTransactions.length > 0 ? (
          sortedTransactions.map(transaction => (
            <TransactionCard key={transaction.id} transaction={transaction} detailed />
          ))
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm text-center">
            <div className="mb-4 text-gray-400">
              <ShoppingCart className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No transactions found</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              {selectedFilter === 'all' 
                ? "You haven't made any transactions yet." 
                : `You don't have any ${selectedFilter} transactions.`}
            </p>
            {selectedFilter !== 'all' && (
              <button 
                onClick={() => setSelectedFilter('all')}
                className="text-primary-600 dark:text-primary-400 hover:underline"
              >
                View all transactions
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Transactions;