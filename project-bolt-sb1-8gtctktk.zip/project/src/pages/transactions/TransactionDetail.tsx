import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, MessageSquare, Calendar, User, DollarSign, MapPin, CheckCircle, Clock, X, AlertTriangle } from 'lucide-react';
import Button from '../../components/ui/Button';
import { useToast } from '../../contexts/ToastContext';

// Mock transaction data
const transaction = {
  id: '1',
  title: 'Research Methods Textbook',
  description: 'Sixth edition, excellent condition with no highlighting or markings.',
  price: 35,
  status: 'completed',
  date: new Date(Date.now() - 172800000).toISOString(),
  completedDate: new Date(Date.now() - 86400000).toISOString(),
  meetingLocation: 'University Library, Main Entrance',
  meetingTime: '3:00 PM',
  image: 'https://images.pexels.com/photos/5834/nature-grass-leaf-green.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  rating: 5,
  review: 'Exactly as described. Alex was punctual and the transaction went smoothly.',
  seller: {
    id: 'user1',
    name: 'Alex Chen',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.8,
    reviewCount: 12
  }
};

const TransactionDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToast } = useToast();
  
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [rating, setRating] = useState(5);
  const [confirmCancel, setConfirmCancel] = useState(false);
  
  // In a real app, you would fetch the transaction data based on the ID
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  const handleSubmitReview = () => {
    setIsSubmittingReview(true);
    
    // Simulate API call
    setTimeout(() => {
      addToast('Review submitted successfully', 'success');
      setIsSubmittingReview(false);
      
      // In a real app, you would update the transaction data
    }, 1000);
  };
  
  const handleCancelTransaction = () => {
    // Simulate API call
    setTimeout(() => {
      addToast('Transaction cancelled successfully', 'success');
      
      // Navigate back to transactions list
      navigate('/transactions');
    }, 1000);
  };
  
  const handleCompleteTransaction = () => {
    // Simulate API call
    setTimeout(() => {
      addToast('Transaction marked as completed', 'success');
      
      // In a real app, you would update the transaction data
      // and probably redirect to leave a review
    }, 1000);
  };
  
  const renderStatusBadge = () => {
    switch (transaction.status) {
      case 'pending':
        return (
          <div className="flex items-center text-yellow-600 dark:text-yellow-400">
            <Clock className="h-5 w-5 mr-1" />
            <span>Pending</span>
          </div>
        );
      case 'completed':
        return (
          <div className="flex items-center text-green-600 dark:text-green-400">
            <CheckCircle className="h-5 w-5 mr-1" />
            <span>Completed</span>
          </div>
        );
      case 'cancelled':
        return (
          <div className="flex items-center text-red-600 dark:text-red-400">
            <X className="h-5 w-5 mr-1" />
            <span>Cancelled</span>
          </div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6 pb-20">
      {/* Back button */}
      <Link 
        to="/transactions" 
        className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Transactions
      </Link>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main transaction details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {transaction.title}
                </h1>
                {renderStatusBadge()}
              </div>
              
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center text-gray-600 dark:text-gray-300">
                  <Calendar className="h-5 w-5 mr-1.5 text-gray-400" />
                  <span>Created: {formatDate(transaction.date)}</span>
                </div>
                
                <div className="flex items-center text-gray-600 dark:text-gray-300">
                  <DollarSign className="h-5 w-5 mr-1.5 text-gray-400" />
                  <span>${transaction.price}</span>
                </div>
                
                {transaction.status === 'completed' && (
                  <div className="flex items-center text-gray-600 dark:text-gray-300">
                    <CheckCircle className="h-5 w-5 mr-1.5 text-gray-400" />
                    <span>Completed: {formatDate(transaction.completedDate)}</span>
                  </div>
                )}
              </div>
              
              <div className="aspect-w-16 aspect-h-9 mb-6">
                <img 
                  src={transaction.image} 
                  alt={transaction.title} 
                  className="object-cover rounded-lg w-full h-60"
                />
              </div>
              
              <div className="space-y-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Description
                </h2>
                <p className="text-gray-700 dark:text-gray-300">
                  {transaction.description}
                </p>
              </div>
            </div>
          </div>
          
          {/* Meeting details */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Meeting Details
            </h2>
            
            <div className="space-y-3">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 mr-3 text-gray-400 mt-0.5" />
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-white">Location</h3>
                  <p className="text-gray-600 dark:text-gray-300">{transaction.meetingLocation}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="h-5 w-5 mr-3 text-gray-400 mt-0.5" />
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-white">Time</h3>
                  <p className="text-gray-600 dark:text-gray-300">{transaction.meetingTime}, {formatDate(transaction.date)}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Reviews section */}
          {transaction.status === 'completed' && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Review
              </h2>
              
              {transaction.review ? (
                <div className="space-y-3">
                  <div className="flex items-center mb-2">
                    {[...Array(5)].map((_, i) => (
                      <svg 
                        key={i}
                        className={`h-5 w-5 ${
                          i < transaction.rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'
                        }`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                      </svg>
                    ))}
                    <span className="ml-2 text-gray-600 dark:text-gray-300 text-sm">
                      {formatDate(transaction.completedDate)}
                    </span>
                  </div>
                  
                  <p className="text-gray-700 dark:text-gray-300">
                    {transaction.review}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-600 dark:text-gray-300">
                    Share your experience with this transaction:
                  </p>
                  
                  <div className="flex items-center mb-2">
                    {[...Array(5)].map((_, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setRating(i + 1)}
                        className="focus:outline-none"
                      >
                        <svg 
                          className={`h-7 w-7 ${
                            i < rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'
                          }`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                        </svg>
                      </button>
                    ))}
                  </div>
                  
                  <textarea
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder="Write your review here..."
                    rows={4}
                    className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  ></textarea>
                  
                  <Button 
                    onClick={handleSubmitReview}
                    isLoading={isSubmittingReview}
                    disabled={reviewText.trim().length === 0}
                  >
                    Submit Review
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Sidebar with seller info and actions */}
        <div className="space-y-6">
          {/* Seller information */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Seller Information
            </h2>
            
            <div className="flex items-center mb-4">
              <img 
                src={transaction.seller.avatar} 
                alt={transaction.seller.name} 
                className="h-12 w-12 rounded-full mr-3"
              />
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white">
                  {transaction.seller.name}
                </h3>
                <div className="flex items-center">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <svg 
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(transaction.seller.rating) 
                            ? 'text-yellow-400' 
                            : i < transaction.seller.rating 
                              ? 'text-yellow-400' 
                              : 'text-gray-300 dark:text-gray-600'
                        }`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                      </svg>
                    ))}
                    <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">
                      ({transaction.seller.reviewCount})
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <Link to={`/profile/${transaction.seller.id}`}>
              <Button variant="outline" fullWidth>
                <User className="h-5 w-5 mr-2" />
                View Profile
              </Button>
            </Link>
          </div>
          
          {/* Actions */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Actions
            </h2>
            
            <div className="space-y-3">
              <Link to={`/chat/${transaction.seller.id}`}>
                <Button variant="outline" fullWidth>
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Message Seller
                </Button>
              </Link>
              
              {transaction.status === 'pending' && (
                <>
                  <Button onClick={handleCompleteTransaction} variant="primary" fullWidth>
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Mark as Completed
                  </Button>
                  
                  {confirmCancel ? (
                    <div className="border border-red-200 dark:border-red-900 rounded-lg p-3 bg-red-50 dark:bg-red-900/20">
                      <div className="flex items-start mb-2">
                        <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-600 dark:text-red-400">
                          Are you sure you want to cancel this transaction? This action cannot be undone.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          onClick={handleCancelTransaction} 
                          variant="danger"
                          size="small"
                        >
                          Yes, Cancel
                        </Button>
                        <Button 
                          onClick={() => setConfirmCancel(false)} 
                          variant="outline"
                          size="small"
                        >
                          No, Keep
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button 
                      onClick={() => setConfirmCancel(true)} 
                      variant="outline" 
                      className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 border-red-300 dark:border-red-700"
                      fullWidth
                    >
                      <X className="h-5 w-5 mr-2" />
                      Cancel Transaction
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionDetail;