import React, { useState } from 'react';
import { User, Mail, School, Book, Calendar, Edit, LogOut, Settings, CheckCircle, Clock, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import Button from '../../components/ui/Button';
import InputField from '../../components/ui/InputField';
import ResourceCard from '../../components/resources/ResourceCard';
import TransactionCard from '../../components/transactions/TransactionCard';

// Mock data
const mockUser = {
  id: 'currentUser',
  displayName: 'John Smith',
  email: 'john.smith@university.edu',
  university: 'State University',
  major: 'Computer Science',
  year: 'Junior',
  joinedDate: 'September 2024',
  avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  rating: 4.7,
  reviewCount: 9
};

const userListings = [
  {
    id: '1',
    title: 'Calculus Textbook (8th Edition)',
    price: 45,
    category: 'Academic',
    image: 'https://images.pexels.com/photos/5834/nature-grass-leaf-green.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    user: {
      id: 'currentUser',
      name: 'John Smith',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Computer Science Tutoring',
    price: 30,
    category: 'Services',
    image: 'https://images.pexels.com/photos/943096/pexels-photo-943096.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
    user: {
      id: 'currentUser',
      name: 'John Smith',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const userTransactions = [
  {
    id: '1',
    title: 'Research Methods Textbook',
    price: 35,
    status: 'completed',
    date: new Date(Date.now() - 172800000).toISOString(),
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Statistical Analysis Tutoring',
    price: 25,
    status: 'pending',
    date: new Date().toISOString(),
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const Profile = () => {
  const { logout, updateProfile } = useAuth();
  const { addToast } = useToast();
  
  const [activeTab, setActiveTab] = useState('listings');
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    displayName: mockUser.displayName,
    university: mockUser.university,
    major: mockUser.major,
    year: mockUser.year
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  
  const handleSaveProfile = async () => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await updateProfile(formData);
      
      addToast('Profile updated successfully', 'success');
      setIsEditing(false);
    } catch (error) {
      addToast('Failed to update profile', 'error');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCancelEdit = () => {
    setFormData({
      displayName: mockUser.displayName,
      university: mockUser.university,
      major: mockUser.major,
      year: mockUser.year
    });
    setIsEditing(false);
  };
  
  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
        <div className="relative h-32 bg-gradient-to-r from-primary-600 to-secondary-500">
          {/* Profile avatar */}
          <div className="absolute bottom-0 left-6 transform translate-y-1/2">
            <div className="relative">
              <img 
                src={mockUser.avatar} 
                alt={mockUser.displayName} 
                className="w-24 h-24 rounded-full border-4 border-white dark:border-gray-800"
              />
              {isEditing && (
                <button className="absolute bottom-0 right-0 bg-white dark:bg-gray-800 rounded-full p-1 shadow-md">
                  <Edit className="h-4 w-4 text-gray-600 dark:text-gray-300" />
                </button>
              )}
            </div>
          </div>
          
          {/* Edit/Save buttons */}
          <div className="absolute bottom-4 right-6">
            {isEditing ? (
              <div className="flex space-x-2">
                <Button 
                  onClick={handleCancelEdit}
                  variant="outline"
                  size="small"
                  className="bg-white"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSaveProfile}
                  size="small"
                  isLoading={isLoading}
                >
                  Save Changes
                </Button>
              </div>
            ) : (
              <Button 
                onClick={() => setIsEditing(true)}
                variant="outline"
                size="small"
                className="bg-white"
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit Profile
              </Button>
            )}
          </div>
        </div>
        
        <div className="pt-16 pb-6 px-6">
          {isEditing ? (
            <div className="space-y-4">
              <InputField
                label="Name"
                name="displayName"
                value={formData.displayName}
                onChange={handleInputChange}
                icon={<User size={20} />}
              />
              
              <InputField
                label="University"
                name="university"
                value={formData.university}
                onChange={handleInputChange}
                icon={<School size={20} />}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField
                  label="Major"
                  name="major"
                  value={formData.major}
                  onChange={handleInputChange}
                  icon={<Book size={20} />}
                />
                
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Year
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Calendar className="h-5 w-5 text-gray-400" />
                    </div>
                    <select
                      name="year"
                      value={formData.year}
                      onChange={handleInputChange}
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="Freshman">Freshman</option>
                      <option value="Sophomore">Sophomore</option>
                      <option value="Junior">Junior</option>
                      <option value="Senior">Senior</option>
                      <option value="Graduate">Graduate</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                {mockUser.displayName}
              </h1>
              
              <div className="flex flex-wrap gap-4 text-gray-600 dark:text-gray-300">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-1.5 text-gray-400" />
                  {mockUser.email}
                </div>
                <div className="flex items-center">
                  <School className="h-5 w-5 mr-1.5 text-gray-400" />
                  {mockUser.university}
                </div>
                <div className="flex items-center">
                  <Book className="h-5 w-5 mr-1.5 text-gray-400" />
                  {mockUser.major}, {mockUser.year}
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-1.5 text-gray-400" />
                  Member since {mockUser.joinedDate}
                </div>
              </div>
              
              <div className="flex items-center mt-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <svg 
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(mockUser.rating) 
                          ? 'text-yellow-400' 
                          : i < mockUser.rating 
                            ? 'text-yellow-400' 
                            : 'text-gray-300 dark:text-gray-600'
                      }`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                  ))}
                  <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                    {mockUser.rating} ({mockUser.reviewCount} reviews)
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Tabs for listings and transactions */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex">
            <button
              onClick={() => setActiveTab('listings')}
              className={`px-6 py-3 text-sm font-medium ${
                activeTab === 'listings'
                  ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                  : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              My Listings
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-6 py-3 text-sm font-medium ${
                activeTab === 'transactions'
                  ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                  : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              My Transactions
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-6 py-3 text-sm font-medium ${
                activeTab === 'settings'
                  ? 'border-b-2 border-primary-500 text-primary-600 dark:text-primary-400'
                  : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
              }`}
            >
              Settings
            </button>
          </nav>
        </div>
        
        <div className="p-6">
          {activeTab === 'listings' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  My Listings ({userListings.length})
                </h2>
                <Button variant="primary" size="small" as="link" to="/create-listing">
                  Create New Listing
                </Button>
              </div>
              
              {userListings.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {userListings.map(listing => (
                    <ResourceCard key={listing.id} resource={listing} showOptions />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    You haven't created any listings yet
                  </p>
                  <Button as="link" to="/create-listing">
                    Create Your First Listing
                  </Button>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                My Transactions ({userTransactions.length})
              </h2>
              
              <div className="flex space-x-2 mb-4">
                <button
                  className="px-3 py-1.5 text-sm rounded-full bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
                >
                  All
                </button>
                <button
                  className="px-3 py-1.5 text-sm rounded-full flex items-center bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1.5" />
                  Completed
                </button>
                <button
                  className="px-3 py-1.5 text-sm rounded-full flex items-center bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  <Clock className="h-4 w-4 mr-1.5" />
                  Pending
                </button>
              </div>
              
              {userTransactions.length > 0 ? (
                <div className="space-y-4">
                  {userTransactions.map(transaction => (
                    <TransactionCard key={transaction.id} transaction={transaction} detailed />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">
                    You don't have any transactions yet
                  </p>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-2xl mx-auto">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Account Settings
              </h2>
              
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Settings className="h-5 w-5 mr-2 text-gray-400" />
                  Preferences
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Email Notifications</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Receive email updates about your account activity
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">SMS Notifications</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Receive text messages for important updates
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Public Profile</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Allow other users to find and view your profile
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                    </label>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-gray-400" />
                  Security
                </h3>
                
                <div className="space-y-4">
                  <Button variant="outline" size="small">
                    Change Password
                  </Button>
                  
                  <Button variant="outline" size="small">
                    Two-Factor Authentication
                  </Button>
                </div>
              </div>
              
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <LogOut className="h-5 w-5 mr-2 text-red-500" />
                  Account
                </h3>
                
                <div className="space-y-4">
                  <Button 
                    onClick={logout}
                    variant="outline" 
                    className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 border-red-300 dark:border-red-700"
                  >
                    Log Out
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 border-red-300 dark:border-red-700"
                  >
                    Deactivate Account
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;