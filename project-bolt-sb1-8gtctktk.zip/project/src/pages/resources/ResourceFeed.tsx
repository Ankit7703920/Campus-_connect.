import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, PlusCircle, Grid, List, BookOpen, Wrench, ShoppingBag } from 'lucide-react';
import ResourceCard from '../../components/resources/ResourceCard';
import ResourceListItem from '../../components/resources/ResourceListItem';
import Button from '../../components/ui/Button';

// Mock data
const resources = [
  {
    id: '1',
    title: 'Calculus Textbook (8th Edition)',
    description: 'Like new condition, no highlights or notes. Includes online access code (unused).',
    price: 45,
    category: 'Academic',
    image: 'https://images.pexels.com/photos/5834/nature-grass-leaf-green.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Physics Lab Equipment Rental',
    description: 'Rent my complete physics lab kit for your experiments. Includes oscilloscope, multimeter, and other essentials.',
    price: 15,
    category: 'Services',
    image: 'https://images.pexels.com/photos/60582/newton-s-cradle-balls-sphere-60582.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    user: {
      id: 'user2',
      name: 'Samantha Lee',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '3',
    title: 'Graphing Calculator TI-84 Plus',
    description: 'Perfect working condition. Battery recently replaced. Great for calculus and statistics classes.',
    price: 30,
    category: 'Items',
    image: 'https://images.pexels.com/photos/53621/calculator-calculation-insurance-finance-53621.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '4',
    title: 'Essay Proofreading & Editing',
    description: 'English major offering professional proofreading and editing services. Quick turnaround and detailed feedback.',
    price: 20,
    category: 'Services',
    image: 'https://images.pexels.com/photos/261510/pexels-photo-261510.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    user: {
      id: 'user4',
      name: 'Emma Wilson',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '5',
    title: 'Desk Lamp with USB Charging Port',
    description: 'Adjustable brightness levels, energy-efficient LED, and built-in USB charging port. Perfect for late-night studying.',
    price: 25,
    category: 'Items',
    image: 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
    user: {
      id: 'user5',
      name: 'David Park',
      avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '6',
    title: 'Computer Science Tutoring',
    description: 'CS major offering tutoring in programming fundamentals, data structures, algorithms, and web development.',
    price: 30,
    category: 'Services',
    image: 'https://images.pexels.com/photos/943096/pexels-photo-943096.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 96).toISOString(),
    user: {
      id: 'user6',
      name: 'Olivia Martinez',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const categories = [
  { id: 'all', name: 'All', icon: <BookOpen size={16} /> },
  { id: 'academic', name: 'Academic', icon: <BookOpen size={16} /> },
  { id: 'services', name: 'Services', icon: <Wrench size={16} /> },
  { id: 'items', name: 'Items', icon: <ShoppingBag size={16} /> }
];

const ResourceFeed = () => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  
  // Filter resources based on search query and selected category
  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || 
                           resource.category.toLowerCase() === selectedCategory.toLowerCase();
    
    const matchesPriceRange = resource.price >= priceRange[0] && resource.price <= priceRange[1];
    
    return matchesSearch && matchesCategory && matchesPriceRange;
  });

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Resource Exchange
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Browse, buy, sell or exchange resources with your fellow students
        </p>
      </div>
      
      {/* Search and filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <div className="flex flex-wrap gap-2 md:flex-nowrap md:items-center">
          <div className="relative flex-grow">
            <input
              type="text"
              placeholder="Search resources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
          </div>
          
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className="p-2 border border-gray-300 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center"
          >
            <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-1" />
            <span className="text-sm">Filters</span>
          </button>
          
          <div className="flex border border-gray-300 dark:border-gray-700 rounded-md overflow-hidden">
            <button 
              onClick={() => setViewMode('grid')} 
              className={`p-2 ${viewMode === 'grid' ? 'bg-gray-100 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'}`}
            >
              <Grid className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            </button>
            <button 
              onClick={() => setViewMode('list')} 
              className={`p-2 ${viewMode === 'list' ? 'bg-gray-100 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'}`}
            >
              <List className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            </button>
          </div>
          
          <Link to="/create-listing">
            <Button variant="primary" className="whitespace-nowrap">
              <PlusCircle className="h-5 w-5 mr-1" />
              <span>New Listing</span>
            </Button>
          </Link>
        </div>
        
        {/* Expanded filters */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Categories
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map(category => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`px-3 py-1.5 text-sm rounded-full flex items-center ${
                        selectedCategory === category.id
                          ? 'bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200'
                          : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      <span className="mr-1.5">{category.icon}</span>
                      {category.name}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Price Range: ${priceRange[0]} - ${priceRange[1]}
                </label>
                <div className="flex gap-4 items-center">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                  />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Sort By
                </label>
                <select className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500">
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                  <option value="priceAsc">Price: Low to High</option>
                  <option value="priceDesc">Price: High to Low</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Resource listings */}
      {filteredResources.length > 0 ? (
        viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredResources.map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredResources.map(resource => (
              <ResourceListItem key={resource.id} resource={resource} />
            ))}
          </div>
        )
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm text-center">
          <div className="mb-4 text-gray-400">
            <Search className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No resources found</h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            We couldn't find any resources matching your search.
          </p>
          <Button onClick={() => {
            setSearchQuery('');
            setSelectedCategory('all');
            setPriceRange([0, 100]);
          }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
};

export default ResourceFeed;