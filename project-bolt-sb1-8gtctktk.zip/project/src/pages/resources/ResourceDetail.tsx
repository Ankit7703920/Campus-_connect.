import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MessageSquare, Share, Flag, Heart, DollarSign, Calendar, Tag } from 'lucide-react';
import Button from '../../components/ui/Button';
import { useToast } from '../../contexts/ToastContext';

// Mock data - in a real app this would come from an API
const resource = {
  id: '1',
  title: 'Calculus Textbook (8th Edition)',
  description: 'Like new condition, no highlights or notes. Includes online access code (unused). This textbook is required for Calculus I, II, and III courses. ISBN: 978-1234567890.',
  price: 45,
  category: 'Academic',
  condition: 'Like New',
  location: 'North Campus Library',
  images: [
    'https://images.pexels.com/photos/5834/nature-grass-leaf-green.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/267586/pexels-photo-267586.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/415071/pexels-photo-415071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  ],
  createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
  views: 24,
  saved: 5,
  user: {
    id: 'user1',
    name: 'Alex Chen',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.8,
    reviewCount: 12,
    joinedDate: 'September 2024'
  }
};

const ResourceDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { addToast } = useToast();
  const [selectedImage, setSelectedImage] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  
  // In a real app, you would fetch the resource data based on the ID
  
  const handleContactSeller = () => {
    // Navigate to chat or start a new conversation
    addToast('Message sent to seller', 'success');
  };
  
  const handleSaveResource = () => {
    setIsSaved(!isSaved);
    addToast(isSaved ? 'Removed from saved items' : 'Added to saved items', 'success');
  };
  
  const handleShareResource = () => {
    // Copy link to clipboard
    navigator.clipboard.writeText(window.location.href);
    addToast('Link copied to clipboard', 'success');
  };
  
  const handleReportResource = () => {
    addToast('Resource reported', 'info');
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Back button */}
      <Link 
        to="/resources" 
        className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Resources
      </Link>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - Images */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
            <div className="aspect-w-16 aspect-h-9 bg-gray-100 dark:bg-gray-700">
              <img 
                src={resource.images[selectedImage]} 
                alt={resource.title} 
                className="object-cover w-full h-[300px] md:h-[400px]"
              />
            </div>
            
            {/* Thumbnail gallery */}
            {resource.images.length > 1 && (
              <div className="p-2 flex justify-center gap-2">
                {resource.images.map((image, index) => (
                  <button 
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-16 h-16 rounded-md overflow-hidden border-2 ${
                      selectedImage === index 
                        ? 'border-primary-500' 
                        : 'border-transparent'
                    }`}
                  >
                    <img 
                      src={image} 
                      alt={`Thumbnail ${index + 1}`} 
                      className="object-cover w-full h-full"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Resource details */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                {resource.title}
              </h1>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200">
                  <Tag className="h-3 w-3 mr-1" />
                  {resource.category}
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900 dark:text-secondary-200">
                  <DollarSign className="h-3 w-3 mr-1" />
                  ${resource.price}
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200">
                  <Calendar className="h-3 w-3 mr-1" />
                  {formatDate(resource.createdAt)}
                </span>
              </div>
              
              <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">
                {resource.description}
              </p>
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Details
              </h2>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                <div>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Condition</dt>
                  <dd className="mt-1 text-sm text-gray-900 dark:text-white">{resource.condition}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Location</dt>
                  <dd className="mt-1 text-sm text-gray-900 dark:text-white">{resource.location}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Listed</dt>
                  <dd className="mt-1 text-sm text-gray-900 dark:text-white">{formatDate(resource.createdAt)}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Views</dt>
                  <dd className="mt-1 text-sm text-gray-900 dark:text-white">{resource.views}</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
        
        {/* Right column - Seller info and actions */}
        <div className="space-y-4">
          {/* Price and action buttons */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Price</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">${resource.price}</p>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={handleSaveResource}
                  className={`p-2 rounded-full ${
                    isSaved 
                      ? 'bg-red-50 text-red-500 dark:bg-red-900/20 dark:text-red-400' 
                      : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400'
                  }`}
                  aria-label={isSaved ? 'Unsave item' : 'Save item'}
                >
                  <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />
                </button>
                <button 
                  onClick={handleShareResource}
                  className="p-2 rounded-full bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400"
                  aria-label="Share"
                >
                  <Share className="h-5 w-5" />
                </button>
                <button 
                  onClick={handleReportResource}
                  className="p-2 rounded-full bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400"
                  aria-label="Report"
                >
                  <Flag className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <Button onClick={handleContactSeller} fullWidth className="mb-2">
              <MessageSquare className="h-5 w-5 mr-2" />
              Contact Seller
            </Button>
            
            <Button variant="outline" fullWidth>
              Make Offer
            </Button>
          </div>
          
          {/* Seller information */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Seller Information
            </h2>
            
            <div className="flex items-center mb-4">
              <img 
                src={resource.user.avatar} 
                alt={resource.user.name} 
                className="h-12 w-12 rounded-full mr-3"
              />
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white">
                  {resource.user.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Member since {resource.user.joinedDate}
                </p>
              </div>
            </div>
            
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <svg 
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(resource.user.rating) 
                        ? 'text-yellow-400' 
                        : i < resource.user.rating 
                          ? 'text-yellow-400' 
                          : 'text-gray-300 dark:text-gray-600'
                    }`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                ))}
                <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                  {resource.user.rating} ({resource.user.reviewCount} reviews)
                </span>
              </div>
            </div>
            
            <Link to={`/profile/${resource.user.id}`}>
              <Button variant="outline" fullWidth>
                View Profile
              </Button>
            </Link>
          </div>
          
          {/* Similar listings */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Similar Listings
            </h2>
            
            <div className="space-y-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Check out these similar items:
              </p>
              
              <Link 
                to="/resources/2" 
                className="block p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <div className="flex">
                  <div className="w-16 h-16 rounded overflow-hidden mr-3 flex-shrink-0">
                    <img 
                      src="https://images.pexels.com/photos/267586/pexels-photo-267586.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                      alt="Related item" 
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white text-sm">
                      Statistics Textbook (5th Edition)
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">$35</p>
                  </div>
                </div>
              </Link>
              
              <Link 
                to="/resources/3" 
                className="block p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <div className="flex">
                  <div className="w-16 h-16 rounded overflow-hidden mr-3 flex-shrink-0">
                    <img 
                      src="https://images.pexels.com/photos/415071/pexels-photo-415071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                      alt="Related item" 
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white text-sm">
                      Chemistry Textbook Bundle
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">$50</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceDetail;