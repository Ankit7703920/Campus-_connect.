import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';
import Button from '../components/ui/Button';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="flex justify-center mb-6">
          <div className="bg-primary-100 dark:bg-primary-900 rounded-full p-6">
            <Search className="h-16 w-16 text-primary-500" />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Page Not Found
        </h1>
        
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          We couldn't find the page you're looking for. The page might have been moved, deleted, or never existed.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button as="link" to="/">
            <Home className="h-5 w-5 mr-2" />
            Back to Home
          </Button>
          
          <Button as="link" to="/resources" variant="outline">
            Browse Resources
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;