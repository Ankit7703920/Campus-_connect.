import React, { useState, useRef, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Send, Paperclip, Image, MoreVertical, Phone, Video } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';

// Mock data
const mockUsers = {
  'user1': {
    id: 'user1',
    name: 'Alex Chen',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isOnline: true,
    lastSeen: null
  },
  'user2': {
    id: 'user2',
    name: 'Samantha Lee',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    isOnline: false,
    lastSeen: new Date(Date.now() - 3600000).toISOString()
  }
};

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  attachment?: {
    type: 'image' | 'file';
    url: string;
    name?: string;
  };
}

// Mock conversation
const mockConversations: Record<string, Message[]> = {
  'user1': [
    {
      id: '1',
      senderId: 'user1',
      text: 'Hey, is the textbook still available?',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      status: 'read'
    },
    {
      id: '2',
      senderId: 'currentUser',
      text: 'Yes, it is! Are you interested in buying it?',
      timestamp: new Date(Date.now() - 82800000).toISOString(),
      status: 'read'
    },
    {
      id: '3',
      senderId: 'user1',
      text: 'Definitely. Is $45 your final price or can we negotiate a bit?',
      timestamp: new Date(Date.now() - 79200000).toISOString(),
      status: 'read'
    },
    {
      id: '4',
      senderId: 'currentUser',
      text: 'I could do $40 if you can pick it up today or tomorrow.',
      timestamp: new Date(Date.now() - 75600000).toISOString(),
      status: 'read'
    },
    {
      id: '5',
      senderId: 'user1',
      text: 'That works for me! Can we meet at the library around 3pm tomorrow?',
      timestamp: new Date(Date.now() - 72000000).toISOString(),
      status: 'read'
    },
    {
      id: '6',
      senderId: 'user1',
      text: 'Here\'s a picture of where I\'ll be sitting:',
      timestamp: new Date(Date.now() - 71900000).toISOString(),
      status: 'read',
      attachment: {
        type: 'image',
        url: 'https://images.pexels.com/photos/256431/pexels-photo-256431.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      }
    },
    {
      id: '7',
      senderId: 'currentUser',
      text: '3pm works perfectly. I\'ll see you at the library tomorrow!',
      timestamp: new Date(Date.now() - 68400000).toISOString(),
      status: 'read'
    },
    {
      id: '8',
      senderId: 'user1',
      text: 'Great! Looking forward to it.',
      timestamp: new Date(Date.now() - 900000).toISOString(),
      status: 'read'
    }
  ],
  'user2': [
    {
      id: '1',
      senderId: 'user2',
      text: 'Hi, I\'m interested in renting your lab equipment for my physics project.',
      timestamp: new Date(Date.now() - 604800000).toISOString(),
      status: 'read'
    },
    {
      id: '2',
      senderId: 'currentUser',
      text: 'Hello! Yes, it\'s available. When do you need it?',
      timestamp: new Date(Date.now() - 518400000).toISOString(),
      status: 'read'
    },
    {
      id: '3',
      senderId: 'user2',
      text: 'I need it for next week, from Monday to Friday.',
      timestamp: new Date(Date.now() - 432000000).toISOString(),
      status: 'read'
    },
    {
      id: '4',
      senderId: 'currentUser',
      text: 'That should work. It\'s $15 per day, so $75 for the whole week.',
      timestamp: new Date(Date.now() - 345600000).toISOString(),
      status: 'read'
    },
    {
      id: '5',
      senderId: 'user2',
      text: 'Perfect! Here\'s my project proposal if you\'re curious:',
      timestamp: new Date(Date.now() - 259200000).toISOString(),
      status: 'read',
      attachment: {
        type: 'file',
        url: '#',
        name: 'Physics_Project_Proposal.pdf'
      }
    },
    {
      id: '6',
      senderId: 'currentUser',
      text: 'Thanks for sharing! Let\'s meet on Monday at 9am at the Science Building?',
      timestamp: new Date(Date.now() - 172800000).toISOString(),
      status: 'read'
    },
    {
      id: '7',
      senderId: 'user2',
      text: 'That works for me. See you then!',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      status: 'read'
    },
    {
      id: '8',
      senderId: 'user2',
      text: 'Thanks for the lab equipment!',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      status: 'read'
    }
  ]
};

const ChatThread = () => {
  const { id } = useParams<{ id: string }>();
  const { currentUser } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [otherUser, setOtherUser] = useState<typeof mockUsers[keyof typeof mockUsers] | null>(null);
  
  useEffect(() => {
    if (id && mockUsers[id]) {
      setOtherUser(mockUsers[id]);
      setMessages(mockConversations[id] || []);
    }
  }, [id]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = () => {
    if (!newMessage.trim() || !id) return;
    
    setIsLoading(true);
    
    // Create a new message object
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: 'currentUser',
      text: newMessage.trim(),
      timestamp: new Date().toISOString(),
      status: 'sent'
    };
    
    // Add the message to the conversation
    setMessages([...messages, newMsg]);
    setNewMessage('');
    
    // Simulate message delivery
    setTimeout(() => {
      setMessages(prevMessages => 
        prevMessages.map(msg => 
          msg.id === newMsg.id ? { ...msg, status: 'delivered' } : msg
        )
      );
      
      // Simulate response after 2 seconds
      setTimeout(() => {
        // Random response based on message content
        let responseText = "Thanks for your message!";
        
        if (newMessage.toLowerCase().includes('price')) {
          responseText = "The price is firm, but I can include free delivery.";
        } else if (newMessage.toLowerCase().includes('meet')) {
          responseText = "I can meet tomorrow at the campus center around noon.";
        } else if (newMessage.toLowerCase().includes('available')) {
          responseText = "Yes, it's still available! When would you like to pick it up?";
        }
        
        const response: Message = {
          id: (Date.now() + 1).toString(),
          senderId: id,
          text: responseText,
          timestamp: new Date().toISOString(),
          status: 'read'
        };
        
        setMessages(prevMessages => [...prevMessages, response]);
        
        // Mark the original message as read
        setMessages(prevMessages => 
          prevMessages.map(msg => 
            msg.id === newMsg.id ? { ...msg, status: 'read' } : msg
          )
        );
        
        setIsLoading(false);
      }, 2000);
    }, 1000);
  };
  
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };
  
  const shouldShowDate = (index: number, timestamp: string) => {
    if (index === 0) return true;
    
    const prevDate = new Date(messages[index - 1].timestamp);
    const currDate = new Date(timestamp);
    
    return prevDate.toDateString() !== currDate.toDateString();
  };
  
  // Function to group consecutive messages from the same sender
  const groupedMessages = messages.reduce<{
    messages: Message[][];
    currentGroup: Message[];
    currentSender: string | null;
  }>(
    (acc, message, index) => {
      // Check if we need to show a date separator
      if (shouldShowDate(index, message.timestamp)) {
        // If there's an existing group, add it to the result
        if (acc.currentGroup.length > 0) {
          acc.messages.push([...acc.currentGroup]);
          acc.currentGroup = [];
        }
        
        // Add a special "date" message
        acc.messages.push([{ 
          id: `date-${index}`, 
          senderId: 'system', 
          text: formatDate(message.timestamp),
          timestamp: message.timestamp,
          status: 'read'
        }]);
        
        acc.currentSender = message.senderId;
        acc.currentGroup = [message];
      } 
      // Check if the sender changed
      else if (message.senderId !== acc.currentSender) {
        // Add the current group to the result and start a new one
        if (acc.currentGroup.length > 0) {
          acc.messages.push([...acc.currentGroup]);
        }
        
        acc.currentSender = message.senderId;
        acc.currentGroup = [message];
      } 
      // Same sender, add to the current group
      else {
        acc.currentGroup.push(message);
      }
      
      // For the last message
      if (index === messages.length - 1 && acc.currentGroup.length > 0) {
        acc.messages.push([...acc.currentGroup]);
      }
      
      return acc;
    },
    { messages: [], currentGroup: [], currentSender: null }
  ).messages;

  return (
    <div className="h-[calc(100vh-7rem)] flex flex-col bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
      {/* Chat header */}
      <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <div className="flex items-center">
          <Link to="/inbox" className="mr-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 md:hidden">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          
          {otherUser && (
            <div className="flex items-center">
              <div className="relative">
                <img 
                  src={otherUser.avatar} 
                  alt={otherUser.name} 
                  className="h-10 w-10 rounded-full"
                />
                {otherUser.isOnline && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-secondary-500 border-2 border-white dark:border-gray-800"></span>
                )}
              </div>
              
              <div className="ml-3">
                <div className="text-sm font-medium text-gray-900 dark:text-white">
                  {otherUser.name}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {otherUser.isOnline ? 'Online' : otherUser.lastSeen ? `Last seen ${new Date(otherUser.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : 'Offline'}
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
            <Phone className="h-5 w-5" />
          </button>
          <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
            <Video className="h-5 w-5" />
          </button>
          <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
            <MoreVertical className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-gray-900">
        {groupedMessages.map((group, groupIndex) => (
          <div key={`group-${groupIndex}`} className="space-y-1">
            {group[0].senderId === 'system' ? (
              <div className="flex justify-center">
                <div className="px-2 py-1 bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 text-xs rounded-md">
                  {group[0].text}
                </div>
              </div>
            ) : (
              <>
                {/* Sender avatar and name (only show for first message in group) */}
                {group[0].senderId !== 'currentUser' && (
                  <div className="flex items-start mb-1">
                    <img 
                      src={mockUsers[group[0].senderId]?.avatar || ''} 
                      alt={mockUsers[group[0].senderId]?.name || ''} 
                      className="h-8 w-8 rounded-full mr-2"
                    />
                    <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {mockUsers[group[0].senderId]?.name || ''}
                    </div>
                  </div>
                )}
                
                {/* Messages */}
                <div className={`flex flex-col ${group[0].senderId === 'currentUser' ? 'items-end' : 'items-start'}`}>
                  {group.map((message, index) => (
                    <div 
                      key={message.id} 
                      className={`max-w-[75%] mb-1 ${index === group.length - 1 ? 'mb-1' : 'mb-0.5'}`}
                    >
                      {/* Message content */}
                      <div 
                        className={`rounded-lg px-3 py-2 inline-block ${
                          message.senderId === 'currentUser'
                            ? 'bg-primary-500 text-white'
                            : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700'
                        }`}
                      >
                        <div className="text-sm">{message.text}</div>
                        
                        {/* Attachment if any */}
                        {message.attachment && (
                          <div className="mt-2">
                            {message.attachment.type === 'image' ? (
                              <img 
                                src={message.attachment.url} 
                                alt="Attached image"
                                className="rounded-md max-w-full"
                              />
                            ) : (
                              <div className="flex items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-md">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                                </svg>
                                <span className="text-sm truncate">
                                  {message.attachment.name || 'Document'}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      
                      {/* Timestamp and status (only for last message in group) */}
                      {index === group.length - 1 && (
                        <div className="flex items-center mt-1">
                          <span className="text-xs text-gray-500 dark:text-gray-400 mr-1">
                            {formatTime(message.timestamp)}
                          </span>
                          
                          {message.senderId === 'currentUser' && (
                            <span className="text-gray-400">
                              {message.status === 'sent' && (
                                <Check className="h-3 w-3" />
                              )}
                              {message.status === 'delivered' && (
                                <CheckCheck className="h-3 w-3" />
                              )}
                              {message.status === 'read' && (
                                <CheckCheck className="h-3 w-3 text-primary-500" />
                              )}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message input */}
      <div className="p-3 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-end space-x-2">
          <button className="p-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
            <Paperclip className="h-5 w-5" />
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
            <Image className="h-5 w-5" />
          </button>
          
          <div className="flex-1 relative">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              rows={1}
              className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 resize-none"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            ></textarea>
          </div>
          
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || isLoading}
            className="!p-2 min-w-[42px]"
            aria-label="Send message"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatThread;