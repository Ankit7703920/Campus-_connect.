import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MoreVertical, Check, CheckCheck } from 'lucide-react';
import MessagePreview from '../../components/messaging/MessagePreview';

// Mock data
const messages = [
  {
    id: '1',
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: true
    },
    lastMessage: 'Hey, is the textbook still available?',
    timestamp: new Date(Date.now() - 900000).toISOString(),
    unread: 2
  },
  {
    id: '2',
    user: {
      id: 'user2',
      name: 'Samantha Lee',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: false
    },
    lastMessage: 'Thanks for the lab equipment!',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    unread: 0
  },
  {
    id: '3',
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: true
    },
    lastMessage: 'I can meet tomorrow at 3pm at the library.',
    timestamp: new Date(Date.now() - 172800000).toISOString(),
    unread: 0
  },
  {
    id: '4',
    user: {
      id: 'user4',
      name: 'Emma Wilson',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: false
    },
    lastMessage: 'Would you accept $40 for the textbook?',
    timestamp: new Date(Date.now() - 259200000).toISOString(),
    unread: 0
  },
  {
    id: '5',
    user: {
      id: 'user5',
      name: 'David Park',
      avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: false
    },
    lastMessage: 'Do you have any other desk lamps available?',
    timestamp: new Date(Date.now() - 604800000).toISOString(),
    unread: 0
  }
];

const Inbox = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  
  // Filter messages based on search query and selected filter
  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          message.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = 
      selectedFilter === 'all' || 
      (selectedFilter === 'unread' && message.unread > 0) ||
      (selectedFilter === 'read' && message.unread === 0);
    
    return matchesSearch && matchesFilter;
  });
  
  // Calculate unread count
  const unreadCount = messages.reduce((count, message) => count + message.unread, 0);

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Messages
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Your conversations with other students
        </p>
      </div>
      
      {/* Search and filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <div className="relative">
          <input
            type="text"
            placeholder="Search messages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
        </div>
        
        <div className="flex mt-4 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`pb-2 px-4 text-sm font-medium ${
              selectedFilter === 'all'
                ? 'text-primary-600 border-b-2 border-primary-500'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setSelectedFilter('unread')}
            className={`pb-2 px-4 text-sm font-medium flex items-center ${
              selectedFilter === 'unread'
                ? 'text-primary-600 border-b-2 border-primary-500'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
            }`}
          >
            Unread
            {unreadCount > 0 && (
              <span className="ml-2 bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 text-xs rounded-full px-2 py-0.5">
                {unreadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setSelectedFilter('read')}
            className={`pb-2 px-4 text-sm font-medium ${
              selectedFilter === 'read'
                ? 'text-primary-600 border-b-2 border-primary-500'
                : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
            }`}
          >
            Read
          </button>
        </div>
      </div>
      
      {/* Message list */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm divide-y divide-gray-200 dark:divide-gray-700">
        {filteredMessages.length > 0 ? (
          filteredMessages.map(message => (
            <MessagePreview key={message.id} message={message} />
          ))
        ) : (
          <div className="p-6 text-center">
            <div className="mb-4 text-gray-400">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </div>
            {searchQuery ? (
              <>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No messages found</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  We couldn't find any messages matching "{searchQuery}"
                </p>
                <button 
                  onClick={() => setSearchQuery('')}
                  className="text-primary-600 dark:text-primary-400 hover:underline"
                >
                  Clear search
                </button>
              </>
            ) : selectedFilter !== 'all' ? (
              <>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No {selectedFilter} messages</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  You don't have any {selectedFilter} messages at the moment
                </p>
                <button 
                  onClick={() => setSelectedFilter('all')}
                  className="text-primary-600 dark:text-primary-400 hover:underline"
                >
                  View all messages
                </button>
              </>
            ) : (
              <>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No messages yet</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  When you connect with other students, your conversations will appear here
                </p>
                <Link 
                  to="/resources"
                  className="text-primary-600 dark:text-primary-400 hover:underline"
                >
                  Browse resources
                </Link>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Inbox;