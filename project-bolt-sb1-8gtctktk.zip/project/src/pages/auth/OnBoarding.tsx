import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, School, BookOpen, Check, ChevronRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import Button from '../../components/ui/Button';
import InputField from '../../components/ui/InputField';

const OnBoarding = () => {
  const [step, setStep] = useState(1);
  const [fullName, setFullName] = useState('');
  const [university, setUniversity] = useState('');
  const [major, setMajor] = useState('');
  const [year, setYear] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { updateProfile } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  
  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    }
  };
  
  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  const handleComplete = async () => {
    try {
      setIsLoading(true);
      await updateProfile({
        displayName: fullName,
        university,
        profileComplete: true
      });
      addToast('Profile setup complete!', 'success');
      navigate('/');
    } catch (err) {
      addToast('Failed to update profile', 'error');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 animate-scale-in">
      {/* Progress indicator */}
      <div className="flex items-center justify-between mb-8">
        <div className="w-full flex items-center">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 1 ? 'bg-primary-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
          }`}>
            {step > 1 ? <Check size={16} /> : 1}
          </div>
          <div className={`flex-1 h-1 mx-2 ${
            step > 1 ? 'bg-primary-500' : 'bg-gray-200 dark:bg-gray-700'
          }`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 2 ? 'bg-primary-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
          }`}>
            {step > 2 ? <Check size={16} /> : 2}
          </div>
          <div className={`flex-1 h-1 mx-2 ${
            step > 2 ? 'bg-primary-500' : 'bg-gray-200 dark:bg-gray-700'
          }`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
            step >= 3 ? 'bg-primary-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
          }`}>
            3
          </div>
        </div>
      </div>
      
      {/* Step content */}
      <div className="space-y-6">
        {step === 1 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Welcome to Campus Connect!</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Let's set up your profile so you can start connecting with other students.</p>
            
            <InputField
              label="Full Name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="John Doe"
              required
              icon={<User size={20} />}
            />
          </>
        )}
        
        {step === 2 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">University Information</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">Tell us about your educational background.</p>
            
            <InputField
              label="University"
              value={university}
              onChange={(e) => setUniversity(e.target.value)}
              placeholder="e.g., University of California"
              required
              icon={<School size={20} />}
            />
            
            <InputField
              label="Major/Field of Study"
              value={major}
              onChange={(e) => setMajor(e.target.value)}
              placeholder="e.g., Computer Science"
              required
              icon={<BookOpen size={20} />}
            />
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Year</label>
              <select
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                required
              >
                <option value="" disabled>Select your year</option>
                <option value="freshman">Freshman</option>
                <option value="sophomore">Sophomore</option>
                <option value="junior">Junior</option>
                <option value="senior">Senior</option>
                <option value="graduate">Graduate</option>
              </select>
            </div>
          </>
        )}
        
        {step === 3 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">You're all set!</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">Here's a summary of your profile information:</p>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">Name:</span>
                <span className="font-medium text-gray-900 dark:text-white">{fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">University:</span>
                <span className="font-medium text-gray-900 dark:text-white">{university}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">Major:</span>
                <span className="font-medium text-gray-900 dark:text-white">{major}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">Year:</span>
                <span className="font-medium text-gray-900 dark:text-white">{year}</span>
              </div>
            </div>
          </>
        )}
      </div>
      
      {/* Navigation buttons */}
      <div className="flex justify-between mt-8">
        {step > 1 ? (
          <Button variant="outline\" onClick={handleBack}>
            Back
          </Button>
        ) : (
          <div></div>
        )}
        
        {step < 3 ? (
          <Button onClick={handleNext} disabled={
            (step === 1 && !fullName) || 
            (step === 2 && (!university || !major || !year))
          }>
            Next <ChevronRight size={16} className="ml-1" />
          </Button>
        ) : (
          <Button onClick={handleComplete} isLoading={isLoading}>
            Complete
          </Button>
        )}
      </div>
    </div>
  );
};

export default OnBoarding;