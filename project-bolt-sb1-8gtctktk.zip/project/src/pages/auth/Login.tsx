import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import Button from '../../components/ui/Button';
import InputField from '../../components/ui/InputField';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Basic validation
    if (!email.includes('@') || !email.includes('.')) {
      setError('Please enter a valid email address');
      return;
    }
    
    if (!email.endsWith('.edu')) {
      setError('Please use your university email address (.edu)');
      return;
    }
    
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    
    try {
      setIsLoading(true);
      await login(email, password);
      addToast('Successfully logged in!', 'success');
      navigate('/');
    } catch (err) {
      setError('Failed to log in. Please check your credentials.');
      addToast('Login failed', 'error');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 animate-scale-in">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">Welcome Back</h2>
      
      {error && (
        <div className="bg-error-50 text-error-500 p-3 rounded-md mb-4 flex items-start">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <InputField
          label="University Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="youremail@university.edu"
          required
          icon={<Mail size={20} />}
        />
        
        <InputField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          required
          icon={<Lock size={20} />}
        />
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-4 w-4 text-primary-500 rounded border-gray-300 focus:ring-primary-500"
            />
            <label htmlFor="remember-me" className="ml-2 text-gray-600 dark:text-gray-300">
              Remember me
            </label>
          </div>
          
          <a href="#" className="text-primary-600 dark:text-primary-400 hover:underline">
            Forgot password?
          </a>
        </div>
        
        <Button type="submit" isLoading={isLoading} fullWidth>
          Sign In
        </Button>
        
        <div className="text-center text-sm text-gray-600 dark:text-gray-300 mt-4">
          Don't have an account?{' '}
          <Link to="/register" className="text-primary-600 dark:text-primary-400 hover:underline">
            Sign up
          </Link>
        </div>
      </form>
    </div>
  );
};

export default Login;