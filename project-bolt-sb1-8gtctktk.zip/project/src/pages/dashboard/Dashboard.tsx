import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, PlusCircle, BookOpen, MessageSquare, BarChart3 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import ResourceCard from '../../components/resources/ResourceCard';
import MessagePreview from '../../components/messaging/MessagePreview';
import TransactionCard from '../../components/transactions/TransactionCard';
import Button from '../../components/ui/Button';

// Mock data
const recentListings = [
  {
    id: '1',
    title: 'Calculus Textbook (8th Edition)',
    price: 45,
    category: 'Academic',
    image: 'https://images.pexels.com/photos/5834/nature-grass-leaf-green.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Physics Lab Equipment Rental',
    price: 15,
    category: 'Services',
    image: 'https://images.pexels.com/photos/60582/newton-s-cradle-balls-sphere-60582.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    user: {
      id: 'user2',
      name: 'Samantha Lee',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '3',
    title: 'Graphing Calculator TI-84 Plus',
    price: 30,
    category: 'Items',
    image: 'https://images.pexels.com/photos/53621/calculator-calculation-insurance-finance-53621.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const recentMessages = [
  {
    id: '1',
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: true
    },
    lastMessage: 'Hey, is the textbook still available?',
    timestamp: new Date(Date.now() - 900000).toISOString(),
    unread: 2
  },
  {
    id: '2',
    user: {
      id: 'user2',
      name: 'Samantha Lee',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      isOnline: false
    },
    lastMessage: 'Thanks for the lab equipment!',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    unread: 0
  }
];

const recentTransactions = [
  {
    id: '1',
    title: 'Research Methods Textbook',
    price: 35,
    status: 'completed',
    date: new Date(Date.now() - 172800000).toISOString(),
    user: {
      id: 'user1',
      name: 'Alex Chen',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  },
  {
    id: '2',
    title: 'Statistical Analysis Tutoring',
    price: 25,
    status: 'pending',
    date: new Date().toISOString(),
    user: {
      id: 'user3',
      name: 'Michael Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  }
];

const Dashboard = () => {
  const { currentUser } = useAuth();
  
  return (
    <div className="space-y-6 pb-20">
      {/* Welcome header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back, {currentUser?.displayName || 'Student'}!
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mt-1">
          Connect with fellow students, share resources, and discover opportunities.
        </p>
      </div>
      
      {/* Search and filter */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <div className="flex items-center">
          <div className="relative flex-grow">
            <input
              type="text"
              placeholder="Search listings, services, or items..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
          </div>
          <button className="ml-2 p-2 border border-gray-300 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700">
            <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400" />
          </button>
          <Link to="/create-listing">
            <Button variant="primary" className="ml-2 whitespace-nowrap">
              <PlusCircle className="h-5 w-5 mr-1" />
              <span className="hidden sm:inline">New Listing</span>
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Recent listings */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
            <BookOpen className="h-5 w-5 mr-2 text-primary-500" />
            Recent Listings
          </h2>
          <Link to="/resources" className="text-primary-500 text-sm hover:underline">
            View all
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recentListings.map(listing => (
            <ResourceCard key={listing.id} resource={listing} />
          ))}
        </div>
      </div>
      
      {/* Messages and Transactions (side by side on desktop) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent messages */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-primary-500" />
              Recent Messages
            </h2>
            <Link to="/inbox" className="text-primary-500 text-sm hover:underline">
              View all
            </Link>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm divide-y divide-gray-200 dark:divide-gray-700">
            {recentMessages.length > 0 ? (
              recentMessages.map(message => (
                <MessagePreview key={message.id} message={message} />
              ))
            ) : (
              <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                No recent messages
              </div>
            )}
          </div>
        </div>
        
        {/* Recent transactions */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-primary-500" />
              Recent Transactions
            </h2>
            <Link to="/transactions" className="text-primary-500 text-sm hover:underline">
              View all
            </Link>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm divide-y divide-gray-200 dark:divide-gray-700">
            {recentTransactions.length > 0 ? (
              recentTransactions.map(transaction => (
                <TransactionCard key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                No recent transactions
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;