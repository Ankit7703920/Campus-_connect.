import React, { ButtonHTMLAttributes, forwardRef } from 'react';
import { Link } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost' | 'danger';
  size?: 'default' | 'small' | 'large';
  isLoading?: boolean;
  fullWidth?: boolean;
  as?: 'button' | 'link';
  to?: string;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(({
  variant = 'primary',
  size = 'default',
  isLoading = false,
  fullWidth = false,
  as = 'button',
  to = '/',
  className = '',
  children,
  ...props
}, ref) => {
  // Base classes
  const baseClasses = `
    inline-flex items-center justify-center font-medium rounded-md
    focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500
    transition-colors duration-200 ease-in-out
    disabled:opacity-70 disabled:cursor-not-allowed
    ${fullWidth ? 'w-full' : ''}
  `;
  
  // Variant classes
  const variantClasses = {
    primary: 'bg-primary-500 hover:bg-primary-600 text-white border border-transparent',
    outline: 'bg-transparent hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600',
    ghost: 'bg-transparent hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 border border-transparent',
    danger: 'bg-red-500 hover:bg-red-600 text-white border border-transparent'
  };
  
  // Size classes
  const sizeClasses = {
    small: 'text-sm px-3 py-1.5',
    default: 'text-sm px-4 py-2',
    large: 'text-base px-6 py-3'
  };
  
  const buttonClasses = `
    ${baseClasses}
    ${variantClasses[variant]}
    ${sizeClasses[size]}
    ${className}
  `;
  
  // Render as link if 'as' prop is 'link'
  if (as === 'link' && to) {
    return (
      <Link
        to={to}
        className={buttonClasses}
      >
        {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
        {children}
      </Link>
    );
  }
  
  // Otherwise render as button
  return (
    <button
      ref={ref}
      className={buttonClasses}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
      {children}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;