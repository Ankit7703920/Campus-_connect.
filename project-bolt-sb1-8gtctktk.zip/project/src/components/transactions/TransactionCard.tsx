import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, CheckCircle, X, Calendar, ChevronRight } from 'lucide-react';

interface User {
  id: string;
  name: string;
  avatar: string;
}

interface Transaction {
  id: string;
  title: string;
  price: number;
  status: 'pending' | 'completed' | 'cancelled';
  date: string;
  user: User;
}

interface TransactionCardProps {
  transaction: Transaction;
  detailed?: boolean;
}

const TransactionCard: React.FC<TransactionCardProps> = ({ transaction, detailed = false }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: detailed ? 'numeric' : undefined
    });
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const getStatusIcon = () => {
    switch (transaction.status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'cancelled':
        return <X className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };
  
  const getStatusText = () => {
    switch (transaction.status) {
      case 'pending':
        return <span className="text-yellow-600 dark:text-yellow-400">Pending</span>;
      case 'completed':
        return <span className="text-green-600 dark:text-green-400">Completed</span>;
      case 'cancelled':
        return <span className="text-red-600 dark:text-red-400">Cancelled</span>;
      default:
        return null;
    }
  };

  return (
    <Link to={`/transactions/${transaction.id}`}>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow duration-200">
        <div className="flex items-center">
          {detailed && (
            <div className="mr-4 hidden sm:block">
              {getStatusIcon()}
            </div>
          )}
          
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
              <h3 className="font-medium text-gray-900 dark:text-white">
                {transaction.title}
              </h3>
              
              <div className="flex items-center mt-1 sm:mt-0">
                {!detailed && getStatusIcon()}
                {detailed ? (
                  <div className="ml-2 text-sm">{getStatusText()}</div>
                ) : (
                  <div className="ml-2 text-sm font-medium text-gray-900 dark:text-white">
                    ${transaction.price}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400">
              <div className="flex items-center mr-4">
                <Calendar className="h-4 w-4 mr-1" />
                <span>{formatDate(transaction.date)}</span>
                {detailed && <span className="ml-1">{formatTime(transaction.date)}</span>}
              </div>
              
              <div className="flex items-center">
                <div className="flex items-center">
                  <img 
                    src={transaction.user.avatar} 
                    alt={transaction.user.name} 
                    className="h-5 w-5 rounded-full mr-1"
                  />
                  <span>{transaction.user.name}</span>
                </div>
              </div>
              
              {detailed && (
                <div className="ml-auto text-primary-500 flex items-center">
                  ${transaction.price}
                </div>
              )}
            </div>
          </div>
          
          <div className="ml-4 text-gray-400">
            <ChevronRight className="h-5 w-5" />
          </div>
        </div>
      </div>
    </Link>
  );
};

export default TransactionCard;