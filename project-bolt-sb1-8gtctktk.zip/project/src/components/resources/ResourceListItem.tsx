import React from 'react';
import { Link } from 'react-router-dom';
import { DollarSign, Clock, MapPin } from 'lucide-react';

interface User {
  id: string;
  name: string;
  avatar: string;
}

interface Resource {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  image: string;
  createdAt: string;
  user: User;
}

interface ResourceListItemProps {
  resource: Resource;
}

const ResourceListItem: React.FC<ResourceListItemProps> = ({ resource }) => {
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHour = Math.round(diffMin / 60);
    const diffDay = Math.round(diffHour / 24);
    
    if (diffSec < 60) {
      return `${diffSec} second${diffSec !== 1 ? 's' : ''} ago`;
    } else if (diffMin < 60) {
      return `${diffMin} minute${diffMin !== 1 ? 's' : ''} ago`;
    } else if (diffHour < 24) {
      return `${diffHour} hour${diffHour !== 1 ? 's' : ''} ago`;
    } else if (diffDay < 7) {
      return `${diffDay} day${diffDay !== 1 ? 's' : ''} ago`;
    } else {
      return past.toLocaleDateString();
    }
  };

  return (
    <Link to={`/resources/${resource.id}`}>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-48 h-48 sm:h-auto flex-shrink-0">
            <img 
              src={resource.image} 
              alt={resource.title} 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="p-4 flex flex-col flex-grow">
            <div className="flex items-center mb-2">
              <span className="px-2 py-1 bg-primary-500 text-white text-xs font-semibold rounded mr-2">
                {resource.category}
              </span>
              <span className="text-gray-600 dark:text-gray-300 text-sm flex items-center">
                <Clock className="h-3.5 w-3.5 mr-1" />
                {formatTimeAgo(resource.createdAt)}
              </span>
            </div>
            
            <h3 className="font-semibold text-gray-900 dark:text-white text-lg mb-2">
              {resource.title}
            </h3>
            
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
              {resource.description}
            </p>
            
            <div className="mt-auto flex items-center justify-between">
              <div className="flex items-center">
                <img 
                  src={resource.user.avatar} 
                  alt={resource.user.name} 
                  className="h-6 w-6 rounded-full mr-2"
                />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {resource.user.name}
                </span>
              </div>
              
              <div className="flex items-center font-semibold text-lg text-primary-600 dark:text-primary-400">
                <DollarSign className="h-5 w-5 mr-0.5" />
                {resource.price}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ResourceListItem;