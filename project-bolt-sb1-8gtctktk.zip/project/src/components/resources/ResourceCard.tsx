import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { DollarSign, Clock, MoreVertical, Edit, Trash, Heart } from 'lucide-react';

interface User {
  id: string;
  name: string;
  avatar: string;
}

interface Resource {
  id: string;
  title: string;
  price: number;
  category: string;
  image: string;
  createdAt: string;
  user: User;
  description?: string;
}

interface ResourceCardProps {
  resource: Resource;
  showOptions?: boolean;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ resource, showOptions = false }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  
  const toggleMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsMenuOpen(!isMenuOpen);
  };
  
  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSaved(!isSaved);
  };
  
  const handleEdit = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Handle edit action
    setIsMenuOpen(false);
  };
  
  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Handle delete action
    setIsMenuOpen(false);
  };
  
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHour = Math.round(diffMin / 60);
    const diffDay = Math.round(diffHour / 24);
    
    if (diffSec < 60) {
      return `${diffSec} second${diffSec !== 1 ? 's' : ''} ago`;
    } else if (diffMin < 60) {
      return `${diffMin} minute${diffMin !== 1 ? 's' : ''} ago`;
    } else if (diffHour < 24) {
      return `${diffHour} hour${diffHour !== 1 ? 's' : ''} ago`;
    } else if (diffDay < 7) {
      return `${diffDay} day${diffDay !== 1 ? 's' : ''} ago`;
    } else {
      return past.toLocaleDateString();
    }
  };

  return (
    <Link to={`/resources/${resource.id}`} className="block">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
        <div className="relative">
          <img 
            src={resource.image} 
            alt={resource.title} 
            className="w-full h-48 object-cover"
          />
          
          <div className="absolute top-2 right-2 flex space-x-1">
            {!showOptions && (
              <button 
                onClick={handleSave}
                className={`p-1.5 rounded-full ${
                  isSaved 
                    ? 'bg-red-500 text-white' 
                    : 'bg-gray-800 bg-opacity-60 text-white hover:bg-opacity-80'
                }`}
              >
                <Heart className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
              </button>
            )}
            
            {showOptions && (
              <div className="relative">
                <button 
                  onClick={toggleMenu}
                  className="p-1.5 rounded-full bg-gray-800 bg-opacity-60 text-white hover:bg-opacity-80"
                >
                  <MoreVertical className="h-4 w-4" />
                </button>
                
                {isMenuOpen && (
                  <div className="absolute right-0 mt-1 w-36 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 overflow-hidden">
                    <button 
                      onClick={handleEdit}
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </button>
                    <button 
                      onClick={handleDelete}
                      className="flex items-center w-full px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Trash className="h-4 w-4 mr-2" />
                      Delete
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-3">
            <div className="flex items-center">
              <span className="px-2 py-1 bg-primary-500 text-white text-xs font-semibold rounded">
                {resource.category}
              </span>
              <span className="ml-2 text-white text-sm flex items-center">
                <DollarSign className="h-3.5 w-3.5 mr-0.5" />
                {resource.price}
              </span>
            </div>
          </div>
        </div>
        
        <div className="p-4">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
            {resource.title}
          </h3>
          
          {resource.description && (
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
              {resource.description}
            </p>
          )}
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img 
                src={resource.user.avatar} 
                alt={resource.user.name} 
                className="h-6 w-6 rounded-full mr-2"
              />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {resource.user.name}
              </span>
            </div>
            
            <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {formatTimeAgo(resource.createdAt)}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ResourceCard;