import React from 'react';
import { Link } from 'react-router-dom';

interface User {
  id: string;
  name: string;
  avatar: string;
  isOnline: boolean;
}

interface Message {
  id: string;
  user: User;
  lastMessage: string;
  timestamp: string;
  unread: number;
}

interface MessagePreviewProps {
  message: Message;
}

const MessagePreview: React.FC<MessagePreviewProps> = ({ message }) => {
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHour = Math.round(diffMin / 60);
    const diffDay = Math.round(diffHour / 24);
    
    if (diffSec < 60) {
      return `${diffSec}s`;
    } else if (diffMin < 60) {
      return `${diffMin}m`;
    } else if (diffHour < 24) {
      return `${diffHour}h`;
    } else if (diffDay < 7) {
      return `${diffDay}d`;
    } else {
      return past.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    }
  };

  return (
    <Link to={`/chat/${message.user.id}`}>
      <div className={`px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200 ${message.unread > 0 ? 'bg-primary-50 dark:bg-primary-900/20' : ''}`}>
        <div className="flex items-center">
          <div className="relative">
            <img 
              src={message.user.avatar} 
              alt={message.user.name} 
              className="h-10 w-10 rounded-full mr-3"
            />
            {message.user.isOnline && (
              <span className="absolute bottom-0 right-2 h-3 w-3 rounded-full bg-secondary-500 border-2 border-white dark:border-gray-800"></span>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-center mb-1">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                {message.user.name}
              </h4>
              <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                {formatTimeAgo(message.timestamp)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <p className={`text-sm truncate ${message.unread > 0 ? 'font-medium text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>
                {message.lastMessage}
              </p>
              {message.unread > 0 && (
                <span className="ml-2 flex-shrink-0 bg-primary-500 text-white text-xs font-medium rounded-full h-5 min-w-5 px-1 flex items-center justify-center">
                  {message.unread}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default MessagePreview;